<?php
header("Location: /hotlines");
exit;
?>
